console.log("----------------------------");
console.log(
  "1B08_TanHongYi-2129570-_LeongKaiJoon-2129707- > BackEnd > config.js"
);
console.log("----------------------------");

//your own secret key
var secret = "s12xyz00";

module.exports.key = secret;
